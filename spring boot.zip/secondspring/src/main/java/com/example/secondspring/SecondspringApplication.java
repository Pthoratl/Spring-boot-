package com.example.secondspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondspringApplication.class, args);
	}

}
