package com.Service;

import java.util.List;

import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dao.DaoSquad;
import com.entity.Team;
@Service
public class ServiceSquad {

	@Autowired
	DaoSquad dao;

	public List<Team> getAllPalyer() {
		List<Team> team = dao.getAllPlayer();
		return team;
	}

	public boolean insertPlayer(Team team) {
		return dao.insertPlayer(team);
	}

	public Team getPlayerByID(int age) {
		return dao.getPlayerByID(age);
	}

	public boolean deletePlayerByID(int age) {
		return dao.deletePlayerByID(age);

	}

}

