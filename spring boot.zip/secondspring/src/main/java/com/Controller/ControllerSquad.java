package com.Controller;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Service.ServiceSquad;
import com.entity.Team;
@RestController
public class ControllerSquad {
	
	@Autowired
	ServiceSquad tm;

	@GetMapping("/all")
	public List<Team> getAllPlayer() {
		List<Team> team = tm.getAllPalyer();
		return team;
	}

	@PostMapping("/add")
	public boolean insertPalyer(@RequestBody Team team) {
		boolean inserted = tm.insertPlayer(team);
		return inserted;
	}

	@GetMapping("player/{age}")
	Team getPlayerByID(@PathVariable int age) {
		Team player = tm.getPlayerByID(age);
		return player;
	}

	@DeleteMapping("/delete/{age}")
	public boolean deletePlayerByID(@PathVariable int age) {
		boolean isDeleted = tm.deletePlayerByID(age);
		return isDeleted;
	}
}