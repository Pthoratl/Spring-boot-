package com.example.secondspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
